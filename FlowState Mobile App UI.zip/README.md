
  # FlowState Mobile App UI

  This is a code bundle for FlowState Mobile App UI. The original project is available at https://www.figma.com/design/BlVo7E3xHQj35YXJY63AfN/FlowState-Mobile-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  