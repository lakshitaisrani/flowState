import { projectId, publicAnonKey } from './supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-bc3e2826`;

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  organization: string;
  phone: string;
  location: string;
  userType: 'researcher' | 'policymaker' | 'general';
  joinDate: string;
  notifications: {
    email: boolean;
    push: boolean;
    sms: boolean;
    alerts: boolean;
  };
  activityStats: {
    sitesMonitored: number;
    alertsHandled: number;
    reportsGenerated: number;
    dataPoints: number;
  };
  achievements: any[];
}

export interface SignupData {
  email: string;
  password: string;
  name: string;
  organization?: string;
  userType?: 'researcher' | 'policymaker' | 'general';
}

export interface LoginData {
  email: string;
  password: string;
}

class ApiClient {
  private getHeaders(useAccessToken: boolean = false): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    if (useAccessToken) {
      const accessToken = localStorage.getItem('accessToken');
      if (accessToken) {
        headers['Authorization'] = `Bearer ${accessToken}`;
      }
    } else {
      headers['Authorization'] = `Bearer ${publicAnonKey}`;
    }

    return headers;
  }

  async signup(data: SignupData): Promise<{ success: boolean; user?: UserProfile; error?: string; message?: string }> {
    try {
      const response = await fetch(`${API_BASE_URL}/signup`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok) {
        console.error('Signup error:', result.error);
        return { success: false, error: result.error };
      }

      return result;
    } catch (error) {
      console.error('Network error during signup:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async login(data: LoginData): Promise<{ success: boolean; user?: UserProfile; accessToken?: string; error?: string }> {
    try {
      const response = await fetch(`${API_BASE_URL}/login`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok) {
        console.error('Login error:', result.error);
        return { success: false, error: result.error };
      }

      // Store access token in localStorage
      if (result.accessToken) {
        localStorage.setItem('accessToken', result.accessToken);
      }

      return result;
    } catch (error) {
      console.error('Network error during login:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async getProfile(): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    try {
      const response = await fetch(`${API_BASE_URL}/profile`, {
        method: 'GET',
        headers: this.getHeaders(true),
      });

      const result = await response.json();

      if (!response.ok) {
        console.error('Get profile error:', result.error);
        return { success: false, error: result.error };
      }

      return result;
    } catch (error) {
      console.error('Network error during profile fetch:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async updateProfile(updates: Partial<UserProfile>): Promise<{ success: boolean; user?: UserProfile; error?: string; message?: string }> {
    try {
      const response = await fetch(`${API_BASE_URL}/profile`, {
        method: 'PUT',
        headers: this.getHeaders(true),
        body: JSON.stringify(updates),
      });

      const result = await response.json();

      if (!response.ok) {
        console.error('Update profile error:', result.error);
        return { success: false, error: result.error };
      }

      return result;
    } catch (error) {
      console.error('Network error during profile update:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async getAllUsers(): Promise<{ success: boolean; totalUsers?: number; maxUsers?: number; users?: any[]; error?: string }> {
    try {
      const response = await fetch(`${API_BASE_URL}/users`, {
        method: 'GET',
        headers: this.getHeaders(true),
      });

      const result = await response.json();

      if (!response.ok) {
        console.error('Get users error:', result.error);
        return { success: false, error: result.error };
      }

      return result;
    } catch (error) {
      console.error('Network error during users fetch:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  logout(): void {
    localStorage.removeItem('accessToken');
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem('accessToken');
  }
}

export const api = new ApiClient();