import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client
const getSupabaseClient = (accessToken?: string) => {
  const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
  const supabaseKey = accessToken || Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  return createClient(supabaseUrl, supabaseKey);
};

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-bc3e2826/health", (c) => {
  return c.json({ status: "ok" });
});

// Signup endpoint
app.post("/make-server-bc3e2826/signup", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, name, organization, userType } = body;

    if (!email || !password || !name) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    // Check if we've reached the 100 user limit
    const allUserIds = await kv.get('users:all') || [];
    if (allUserIds.length >= 100) {
      return c.json({ error: 'User limit reached. Maximum 100 users allowed.' }, 403);
    }

    // Create user with Supabase Auth
    const supabase = getSupabaseClient(Deno.env.get('SUPABASE_SERVICE_ROLE_KEY'));
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (authError) {
      console.log(`Auth error during signup: ${authError.message}`);
      return c.json({ error: authError.message }, 400);
    }

    const userId = authData.user.id;

    // Create user profile in KV store
    const userProfile = {
      id: userId,
      email,
      name,
      organization: organization || '',
      phone: '',
      location: '',
      userType: userType || 'general',
      joinDate: new Date().toISOString(),
      notifications: {
        email: true,
        push: true,
        sms: false,
        alerts: true
      },
      activityStats: {
        sitesMonitored: 0,
        alertsHandled: 0,
        reportsGenerated: 0,
        dataPoints: 0
      },
      achievements: []
    };

    await kv.set(`user:${userId}`, userProfile);

    // Add user ID to the list of all users
    const updatedUserIds = [...allUserIds, userId];
    await kv.set('users:all', updatedUserIds);

    console.log(`User created successfully: ${email}`);
    return c.json({ 
      success: true, 
      user: userProfile,
      message: 'Account created successfully' 
    });

  } catch (error) {
    console.log(`Error during signup: ${error}`);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Login endpoint
app.post("/make-server-bc3e2826/login", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password } = body;

    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400);
    }

    // Sign in with Supabase Auth
    const supabase = getSupabaseClient();
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.log(`Auth error during login: ${error.message}`);
      return c.json({ error: error.message }, 401);
    }

    const userId = data.user.id;
    const accessToken = data.session.access_token;

    // Get user profile from KV store
    const userProfile = await kv.get(`user:${userId}`);

    if (!userProfile) {
      console.log(`User profile not found for user: ${userId}`);
      return c.json({ error: 'User profile not found' }, 404);
    }

    console.log(`User logged in successfully: ${email}`);
    return c.json({ 
      success: true, 
      user: userProfile,
      accessToken
    });

  } catch (error) {
    console.log(`Error during login: ${error}`);
    return c.json({ error: 'Internal server error during login' }, 500);
  }
});

// Get user profile endpoint (requires authentication)
app.get("/make-server-bc3e2826/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    // Verify user with access token
    const supabase = getSupabaseClient();
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      console.log(`Auth error during profile fetch: ${error?.message}`);
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Get user profile from KV store
    const userProfile = await kv.get(`user:${user.id}`);

    if (!userProfile) {
      console.log(`User profile not found for user: ${user.id}`);
      return c.json({ error: 'User profile not found' }, 404);
    }

    return c.json({ success: true, user: userProfile });

  } catch (error) {
    console.log(`Error fetching profile: ${error}`);
    return c.json({ error: 'Internal server error while fetching profile' }, 500);
  }
});

// Update user profile endpoint (requires authentication)
app.put("/make-server-bc3e2826/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    // Verify user with access token
    const supabase = getSupabaseClient();
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      console.log(`Auth error during profile update: ${error?.message}`);
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const body = await c.req.json();
    const { name, phone, location, organization, notifications, activityStats } = body;

    // Get existing profile
    const existingProfile = await kv.get(`user:${user.id}`);

    if (!existingProfile) {
      console.log(`User profile not found for user: ${user.id}`);
      return c.json({ error: 'User profile not found' }, 404);
    }

    // Update profile
    const updatedProfile = {
      ...existingProfile,
      name: name || existingProfile.name,
      phone: phone !== undefined ? phone : existingProfile.phone,
      location: location !== undefined ? location : existingProfile.location,
      organization: organization !== undefined ? organization : existingProfile.organization,
      notifications: notifications || existingProfile.notifications,
      activityStats: activityStats || existingProfile.activityStats
    };

    await kv.set(`user:${user.id}`, updatedProfile);

    console.log(`User profile updated successfully for: ${user.email}`);
    return c.json({ 
      success: true, 
      user: updatedProfile,
      message: 'Profile updated successfully' 
    });

  } catch (error) {
    console.log(`Error updating profile: ${error}`);
    return c.json({ error: 'Internal server error while updating profile' }, 500);
  }
});

// Get all users endpoint (for admin purposes, returns count and limited info)
app.get("/make-server-bc3e2826/users", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'No authorization token provided' }, 401);
    }

    // Verify user with access token
    const supabase = getSupabaseClient();
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Get all user IDs
    const allUserIds = await kv.get('users:all') || [];

    // Get all user profiles
    const userProfiles = await kv.mget(allUserIds.map(id => `user:${id}`));

    const usersInfo = userProfiles.map(profile => ({
      id: profile.id,
      name: profile.name,
      email: profile.email,
      userType: profile.userType,
      joinDate: profile.joinDate
    }));

    return c.json({ 
      success: true, 
      totalUsers: allUserIds.length,
      maxUsers: 100,
      users: usersInfo
    });

  } catch (error) {
    console.log(`Error fetching users: ${error}`);
    return c.json({ error: 'Internal server error while fetching users' }, 500);
  }
});

Deno.serve(app.fetch);