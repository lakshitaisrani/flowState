import React, { useState, useEffect } from 'react';
import { AuthScreens } from './components/AuthScreens';
import { HomeDashboard } from './components/HomeDashboard';
import { LocationMap } from './components/LocationMap';
import { SiteDetails } from './components/SiteDetails';
import { UserProfile } from './components/UserProfile';
import { Notifications } from './components/Notifications';
import { ResearcherDashboard } from './components/ResearcherDashboard';
import { PolicymakerDashboard } from './components/PolicymakerDashboard';
import { BottomNavigation } from './components/BottomNavigation';
import { api, UserProfile as UserProfileType } from './utils/api';

type UserType = 'researcher' | 'policymaker' | 'general';
type Screen = 'auth' | 'home' | 'map' | 'site-details' | 'notifications' | 'profile' | 'research' | 'policy';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('auth');
  const [userType, setUserType] = useState<UserType>('general');
  const [userProfile, setUserProfile] = useState<UserProfileType | null>(null);
  const [selectedSiteId, setSelectedSiteId] = useState<string>('');
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  
  // Mock notification count - in a real app this would come from an API
  const notificationCount = 3;

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      if (api.isAuthenticated()) {
        const result = await api.getProfile();
        if (result.success && result.user) {
          setUserProfile(result.user);
          setUserType(result.user.userType);
          setCurrentScreen('home');
        } else {
          api.logout();
        }
      }
      setIsCheckingAuth(false);
    };

    checkSession();
  }, []);

  const handleLogin = (type: UserType, profile: UserProfileType) => {
    setUserType(type);
    setUserProfile(profile);
    setCurrentScreen('home');
  };

  const handleScreenChange = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const handleSiteSelect = (siteId: string) => {
    setSelectedSiteId(siteId);
    setCurrentScreen('site-details');
  };

  const handleBackFromSiteDetails = () => {
    setCurrentScreen('map');
  };

  const handleSignOut = () => {
    api.logout();
    setCurrentScreen('auth');
    setUserType('general');
    setUserProfile(null);
    setSelectedSiteId('');
  };

  const handleProfileUpdate = (updatedProfile: UserProfileType) => {
    setUserProfile(updatedProfile);
  };

  // Show loading state while checking authentication
  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-blue-700">Loading...</p>
        </div>
      </div>
    );
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'auth':
        return <AuthScreens onLogin={handleLogin} />;
      
      case 'home':
        return <HomeDashboard userType={userType} />;
      
      case 'map':
        return <LocationMap onSiteSelect={handleSiteSelect} />;
      
      case 'site-details':
        return (
          <SiteDetails 
            siteId={selectedSiteId} 
            onBack={handleBackFromSiteDetails} 
          />
        );
      
      case 'notifications':
        return <Notifications />;
      
      case 'profile':
        return (
          <UserProfile 
            userType={userType} 
            userProfile={userProfile}
            onSignOut={handleSignOut}
            onProfileUpdate={handleProfileUpdate}
          />
        );
      
      case 'research':
        return userType === 'researcher' ? <ResearcherDashboard /> : <HomeDashboard userType={userType} />;
      
      case 'policy':
        return userType === 'policymaker' ? <PolicymakerDashboard /> : <HomeDashboard userType={userType} />;
      
      default:
        return <HomeDashboard userType={userType} />;
    }
  };

  const showBottomNavigation = currentScreen !== 'auth' && currentScreen !== 'site-details';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <div className={`${showBottomNavigation ? 'pb-20' : ''}`}>
        {renderScreen()}
      </div>

      {/* Bottom Navigation */}
      {showBottomNavigation && (
        <BottomNavigation
          activeScreen={currentScreen}
          onScreenChange={handleScreenChange}
          userType={userType}
          notificationCount={notificationCount}
        />
      )}
    </div>
  );
}